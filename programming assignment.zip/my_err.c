/* my_err.c is for handling error */

err_sys(s)
char* s;
{
	printf("\n%s", s);
	exit(0);
}

err_dump(s)
char* s;
{
	printf("\n%s", s);
	exit(0);
}

